// כל המשתנים שצריכים להיות סודיים יהיו בקובץ הזה
exports.config = {
  tokenSecret:"monkeysTokenSecret"
}

