const mongoose = require('mongoose');

main().catch(err => console.log(err));

async function main() {
  await mongoose.connect('mongodb+srv://koko77:M312@cluster0.jqisdsakq.mongodb.net/monkeys24');
  console.log("mongo connect monkeys24 atlas")
  // use `await mongoose.connect('mongodb://user:password@localhost:27017/test');` if your database has auth enabled
}